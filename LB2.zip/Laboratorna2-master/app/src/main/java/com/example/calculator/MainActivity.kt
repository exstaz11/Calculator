package com.example.calculator
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.calculator.R.id.vidp

class MainActivity : AppCompatActivity() {
    var etext: EditText? = null
    var etext2: EditText? = null

    var btnplus: Button? = null
    var btnmin: Button? = null

    var btndivision: Button? = null
    var btnmultiply: Button? = null

    var result: TextView? = null

    var n1: Float? = null
    var n2: Float? = null

    private lateinit var vidp: Button
    private lateinit var clear: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etext = findViewById(R.id.firstvalue)
        etext2 = findViewById(R.id.secondvalue)
        btnplus = findViewById(R.id.btnplus)
        btnmin = findViewById(R.id.btnmin)
        btnmultiply = findViewById(R.id.btnmultiply)
        btndivision = findViewById(R.id.btndivision)
        vidp = findViewById(R.id.vidp)
        clear = findViewById(R.id.clear)
        Clicklistener()
    }

    fun Clicklistener() {
        val intent = Intent(this, ResultActivity::class.java)
        btnplus!!.setOnClickListener {
            n1 = etext!!.text.toString().toFloat()
            n2 = etext2!!.text.toString().toFloat()
            val sum: Float = n1!! + n2!!
            result?.text = sum.toString()
            intent.putExtra("answer", sum.toString())

        }

        btnmin!!.setOnClickListener {
            n1 = etext!!.text.toString().toFloat()
            n2 = etext2!!.text.toString().toFloat()
            val sum: Float = n1!! - n2!!
            result?.text = sum.toString()
            intent.putExtra("answer", sum.toString())

        }
        btnmultiply!!.setOnClickListener {
            n1 = etext!!.text.toString().toFloat()
            n2 = etext2!!.text.toString().toFloat()
            val sum: Float = n1!! * n2!!
            result?.text = sum.toString()
            intent.putExtra("answer", sum.toString())

        }
        btndivision!!.setOnClickListener {
            n1 = etext!!.text.toString().toFloat()
            n2 = etext2!!.text.toString().toFloat()
            val sum: Float = n1!! / n2!!
            result?.text = sum.toString()
            intent.putExtra("answer", sum.toString())

        }

        vidp.setOnClickListener {
            if (etext!!.text.toString().isEmpty() || etext2!!.text.toString().isEmpty()){
                intent.putExtra("answer","Немає відповіді")
            }
            startActivity(intent)
        }
        clear.setOnClickListener{
            val empty = ""
            etext!!.setText(empty)
            etext2!!.setText(empty)
        }
    }
}